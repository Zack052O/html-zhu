 // 轮播图
 function changeSlide(slideNumber) {
    // 更改指示器的形状
    const indicators = document.querySelectorAll('.carousel-indicator');
    indicators.forEach((indicator, index) => {
        indicator.classList.toggle('active', index === slideNumber);
    });
}
// 页面加载时设置第一个指示器为激活状态
document.addEventListener('DOMContentLoaded', () => {
    changeSlide(0);

    // 为指示器设置点击事件监听
    document.querySelectorAll('.carousel-indicator').forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            changeSlide(index);
        });
    });
});


// 第二页
document.addEventListener('DOMContentLoaded', function () {
    var navLinks = document.querySelectorAll('.nav-link');
    var contentPanes = document.querySelectorAll('.content-pane');

    navLinks.forEach(function (link) {
        link.addEventListener('click', function (event) {
            event.preventDefault();
            // 移除所有链接和内容盒子的激活状态
            navLinks.forEach(function (lnk) { lnk.classList.remove('active'); });
            contentPanes.forEach(function (pane) { pane.classList.remove('active'); });

            // 为被点击的链接和相应的内容盒子添加激活状态
            this.classList.add('active');
            var targetId = this.getAttribute('data-target');
            var targetPane = document.getElementById(targetId);
            if (targetPane) {
                targetPane.classList.add('active');
            }
        });
    });

    // 页面加载时自动点击第一个导航链接，以显示第一个内容盒子
    if (navLinks.length > 0) {
        navLinks[0].click();
    }
});